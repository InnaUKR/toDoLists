$(function () {
    $('.star-priority-new').raty({
        path: '/assets',
        scoreName: 'task[priority]'
    });
});
